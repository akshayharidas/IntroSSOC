python exp.py > exploit.txt
./cp exploit.txt file.out

