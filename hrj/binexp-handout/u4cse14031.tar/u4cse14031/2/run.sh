python exp.py > out.txt
setarch x86_64 -R ./cp2 out.txt file2.txt
