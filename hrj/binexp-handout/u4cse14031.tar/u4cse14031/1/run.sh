python exp.py > out.txt
setarch x86_64 -R ./cp1 out.txt file2.txt
