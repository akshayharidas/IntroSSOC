 finding length
it has 3 input
it only takes3 put if it is lessthan or greather than will make rax 0 and exit
here we are using atoi that is ASCII to Integer

