#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#finding length
int main(){
	string str1,str2,str3;
	scanf("%s",&str1);
	scanf("%s",&str2);
	scanf("%s",&str3);
