gcc demo.c
