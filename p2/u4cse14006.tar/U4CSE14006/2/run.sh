python demo.py 
./vulnerable.out < exploit.txt
