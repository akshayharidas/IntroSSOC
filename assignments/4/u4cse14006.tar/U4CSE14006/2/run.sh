#!/bin/sh
python demo.py > exploit.txt
