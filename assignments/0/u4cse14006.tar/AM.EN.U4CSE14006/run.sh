#!/bin/bash

./helloworld.sh
