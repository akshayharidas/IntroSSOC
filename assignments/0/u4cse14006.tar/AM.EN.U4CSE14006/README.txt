Q1
Problem: program to print hello world 

language used : Shell scripting
