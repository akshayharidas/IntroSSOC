python exploit.py> exploit.txt
