

#include<stdio.h>
#inclide<math.h>
#include<string.h>

int main(int argc, char **argv)
{
    for (int i = 0; i < 22; ++i)
    {
	sacnf("%s",&argv[i]);
	}
	int a = strlen(arv[0]);
	int b = strlen(arv[1]);
	if(a>b)
	{
	printf("1");
	
	}
	else if(a<b){
	printf("-1");
	}
	else{
	prinf("0");
	}
        ;printf("argv[%d]: %s\n", i, argv[i]);
    

}
